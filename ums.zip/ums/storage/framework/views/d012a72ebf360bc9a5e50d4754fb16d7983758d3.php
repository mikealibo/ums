<?php $__env->startSection('content'); ?>

<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <?php echo Form::open(['action'=>['PostsController@destroy', $post->id], 'method'=>'POST', 'class' => 'pull-right']); ?>

    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

    <?php echo e(Form::submit('Delete', ['class'=>'btn btn-danger'])); ?>

    <?php echo Form::close(); ?>

    <h1 class="display-4"><?php echo e($post->fullname); ?></h1>
    <p class="lead">Age : <?php echo e($post->age); ?></p>
    <p class="lead">Address : <?php echo e($post->address); ?></p>
    <p class="lead">Contact Number : <?php echo e($post->contactno); ?></p>
    <p class="lead">Email : <?php echo e($post->email); ?></p>

    <a href="/ums" class="btn btn-primary">Go Back</a>

    <a href="<?php echo e($post->id); ?>/edit" class="btn btn-success">Update</a>
  </div>
 
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>