<?php $__env->startSection('content'); ?>
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">Edit User's Information</h1>

<?php echo Form::open(['action' => ['PostsController@update', $post->id], 'method' => 'POST']); ?>

	
	<div class="row">
		<div class="col-md-6 offset-md-1">
			<div class="form-group">
				<?php echo e(Form::text('fname', $post->fullname, ['class'=>'form-control', 'placeholder'=>'Full name'])); ?>

			</div>
			<div class="form-group">
				<?php echo e(Form::text('age', $post->age, ['class'=>'form-control', 'placeholder'=>'Age'])); ?>

			</div>
			<div class="form-group">
				<?php echo e(Form::text('address', $post->address, ['class'=>'form-control', 'placeholder'=>'Location'])); ?>

			</div>
			<div class="form-group">
				<?php echo e(Form::text('contactno', $post->contactno, ['class'=>'form-control', 'placeholder'=>'Contact Number'])); ?>

			</div>
			<div class="form-group">
				<?php echo e(Form::text('email', $post->email, ['class'=>'form-control', 'placeholder'=>'E-mail Address'])); ?>

			</div>
			<div class="form-group">
				<?php echo e(Form::hidden('_method', 'PUT')); ?>

				<?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

				
			</div>
		</div>
	</div>

<?php echo Form::close(); ?>

  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>