<?php

// This is was already connected to the controller
// all needed routes are already in here 
Route::resource('ums', 'PostsController');

// This is for the authentication routes
Auth::routes();
