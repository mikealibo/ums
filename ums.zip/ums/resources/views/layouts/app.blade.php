<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<title>{{config('app.name')}}</title>
</head>

<body>
@guest
<header>

<div class="collapse bg-dark" id="navbarHeader">
    <div class="container">
        <div class="row">

<div class="col-sm-8 col-md-7 py-4">
    <h4 class="text-white">About</h4>
        <p class="text-muted">The User Management System provides functionality to manage users and personal profiles. It is reliable, extensible and open for easier integration with existent systems. UMS implements user management and authentication, personal profiles management and classification.</p>
</div>

<div class="col-sm-4 offset-md-1 py-4">
    <h4 class="text-white">{{ __('Login') }}</h4>

<form method="POST" action="{{ route('login') }}">

@csrf
<div class="form-group row">
<div class="col-md-12">
<input id="email" type="email" placeholder="E-mail Address" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }} form-control-sm" name="email" value="{{ old('email') }}" required autofocus>

@if ($errors->has('email'))
<span class="invalid-feedback" role="alert">
<strong>{{ $errors->first('email') }}</strong>
</span>
 @endif
</div>
</div>

<div class="form-group row">
<div class="col-md-12">
<input id="password" type="password" placeholder="Password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }} form-control-sm" name="password" required>

@if ($errors->has('password'))
<span class="invalid-feedback" role="alert">
<strong>{{ $errors->first('password') }}</strong>
</span>
@endif
</div>
</div>
<div class="form-group row">

<div class="col-md-12">
<div class="form-check">
<input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
<label class="form-check-label text-white" for="remember">{{ __('Remember Me') }}</label>
</div>
</div>
</div>

<div class="form-group row mb-0">
    <div class="col-md-12 ">
        <button type="submit" class="btn btn-primary">
            {{ __('Login') }}
        </button>
</br>
<a class="btn btn-link text-white" href="{{ route('password.request') }}">{{ __('Forgot Your Password?') }}</a>
</div>
</div>
</form>
</div>


</div>
</div>
</div>

<div class="navbar navbar-dark shadow-sm" style="background-color: mediumseagreen">
    <div class="container d-flex justify-content-between">
        <a href="/ums" class="navbar-brand d-flex align-items-center">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>
        <strong>User Management System</strong></a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>

        </div>
      </div>
</header>
@else
<nav class="navbar navbar-expand-lg navbar-light" style="background-color: mediumseagreen;color: white;">
  <a class="navbar-brand">User Management System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/ums">Dashboard <span class="sr-only">(current)</span></a>
      </li>

    </ul>
    <ul class="navbar-nav mr-right">
      <li class="nav-item">
        <a class="nav-link" href="{{ route('logout') }}"
           onclick="event.preventDefault();
          document.getElementById('logout-form').submit();">
          {{ __('Logout') }}
        </a>
  <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
   @csrf
  </form>
      </li>

    </ul>
  </div>
</nav>
@endguest
@include('inc.messages')
@yield('content')


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    </body>
</html>
