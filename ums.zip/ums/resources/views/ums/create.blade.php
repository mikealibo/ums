@extends('layouts.app')


@section('content')
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">Create New User's</h1>

{!! Form::open(['action' => 'PostsController@store', 'method' => 'POST']) !!}
	
	<div class="row">
		<div class="col-md-6 offset-md-1">
			<div class="form-group">
				{{Form::text('fname', '', ['class'=>'form-control', 'placeholder'=>'Full name'])}}
			</div>
			<div class="form-group">
				{{Form::text('age', '', ['class'=>'form-control', 'placeholder'=>'Age'])}}
			</div>
			<div class="form-group">
				{{Form::text('address', '', ['class'=>'form-control', 'placeholder'=>'Location'])}}
			</div>
			<div class="form-group">
				{{Form::text('contactno', '', ['class'=>'form-control', 'placeholder'=>'Contact Number'])}}
			</div>
			<div class="form-group">
				{{Form::text('email', '', ['class'=>'form-control', 'placeholder'=>'E-mail Address'])}}
			</div>
			<div class="form-group">
				{{Form::submit('Submit',['class'=>'btn btn-primary'])}}
			</div>
		</div>
	</div>

{!! Form::close() !!}
  </div>
</div>


@endsection