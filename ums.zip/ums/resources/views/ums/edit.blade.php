@extends('layouts.app')


@section('content')
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">Edit User's Information</h1>

{!! Form::open(['action' => ['PostsController@update', $post->id], 'method' => 'POST']) !!}
	
	<div class="row">
		<div class="col-md-6 offset-md-1">
			<div class="form-group">
				{{Form::text('fname', $post->fullname, ['class'=>'form-control', 'placeholder'=>'Full name'])}}
			</div>
			<div class="form-group">
				{{Form::text('age', $post->age, ['class'=>'form-control', 'placeholder'=>'Age'])}}
			</div>
			<div class="form-group">
				{{Form::text('address', $post->address, ['class'=>'form-control', 'placeholder'=>'Location'])}}
			</div>
			<div class="form-group">
				{{Form::text('contactno', $post->contactno, ['class'=>'form-control', 'placeholder'=>'Contact Number'])}}
			</div>
			<div class="form-group">
				{{Form::text('email', $post->email, ['class'=>'form-control', 'placeholder'=>'E-mail Address'])}}
			</div>
			<div class="form-group">
				{{Form::hidden('_method', 'PUT')}}
				{{Form::submit('Submit',['class'=>'btn btn-primary'])}}
				
			</div>
		</div>
	</div>

{!! Form::close() !!}
  </div>
</div>


@endsection