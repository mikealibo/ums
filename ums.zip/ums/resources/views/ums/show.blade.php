@extends('layouts.app')


@section('content')

<div class="jumbotron jumbotron-fluid">
  <div class="container">
    {!!Form::open(['action'=>['PostsController@destroy', $post->id], 'method'=>'POST', 'class' => 'pull-right'])!!}
    {{Form::hidden('_method', 'DELETE')}}
    {{Form::submit('Delete', ['class'=>'btn btn-danger'])}}
    {!!Form::close()!!}
    <h1 class="display-4">{{$post->fullname}}</h1>
    <p class="lead">Age : {{$post->age}}</p>
    <p class="lead">Address : {{$post->address}}</p>
    <p class="lead">Contact Number : {{$post->contactno}}</p>
    <p class="lead">Email : {{$post->email}}</p>

    <a href="/ums" class="btn btn-primary">Go Back</a>

    <a href="{{$post->id}}/edit" class="btn btn-success">Update</a>
  </div>
 
</div>


@endsection