@extends('layouts.app')

@section('content')

@guest
<div class="container">
  <div class="row">

    <div class="col-md-8">
      <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1 class="display-4">Welcome to my </br>User Management System</h1>
        <p class="lead">User management describes the ability for administrators to manage user access to various IT resources like systems, devices, applications, storage systems, networks, SaaS services, and more. ... User management enables admins to control user access and on-board and off-board users to and from IT resources.</p>
      </div>
    </div>
    </div>

    <div class="col-md-4">
  <h1 class="display-4">Register</h1>
  <form method="POST" action="{{ route('register') }}">
    @csrf

<div class="form-group row">
  <div class="col-md-12">
  <input id="name" type="text" placeholder="Name" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name') }}" required autofocus>

  @if ($errors->has('name'))
    <span class="invalid-feedback" role="alert">
    <strong>{{ $errors->first('name') }}</strong>
    </span>
  @endif
  </div>
  </div>

<div class="form-group row">
  <div class="col-md-12">
    <input id="email" type="email" placeholder="E-mail Address" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required>
  
  @if ($errors->has('email'))
    <span class="invalid-feedback" role="alert">
      <strong>{{ $errors->first('email') }}</strong>
    </span>
  @endif
  </div>
</div>

<div class="form-group row">
  <div class="col-md-12">
    <input id="password" type="password" placeholder="Password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>

  @if ($errors->has('password'))
    <span class="invalid-feedback" role="alert">
    <strong>{{ $errors->first('password') }}</strong>
    </span>
    @endif
  </div>
  </div>
  
<div class="form-group row">
  <div class="col-md-12">
  <input id="password-confirm" type="password" placeholder="Confirm Password" class="form-control" name="password_confirmation" required>
  </div>
</div>

<div class="form-group row mb-0">
  <div class="col-md-12">
    <button type="submit" class="btn btn-primary">
      {{ __('Register') }}
    </button>
    </div>
  </div>
</form>
</div>

  </div>
</div>


@else

<h1 class="display-4 text-center">User's List</h1>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <a href="http://localhost:8000/ums/create" class="btn btn-success">Create New User</a>
    </br></br>
    </div>
    <div class="col-md-12">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Fullname</th>
            <th scope="col">Age</th>
            <th scope="col">Location</th>
            <th scope="col">Email</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
      <tbody>
      @if(count($posts) > 0)
          @foreach($posts as $post)
          <tr>
            <td>{{$post->id}}</td>
            <td>{{$post->fullname}}</td>
            <td>{{$post->age}}</td>
            <td>{{$post->address}}</td>
            <td>{{$post->email}}</td>
            <td><a href="ums/{{$post->id}}" class="btn btn-info">View</a> | <a href="ums/{{$post->id}}/edit" class="btn btn-success">Update</a>



              
          </tr>
          @endforeach
        </tbody>
      </table>
      </div>

      @else
        <div class="alert alert-danger">No Records found in database. Please insert by clicking Create New User.</div>
      @endif
    </div>
    {{$posts->links()}}
  </div>

</div>

@endguest


@endsection