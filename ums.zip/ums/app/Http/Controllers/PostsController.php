<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;

class PostsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $posts = Post::orderBy('id', 'desc')->paginate(10);
        return view('ums.index')->with('posts', $posts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('ums.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'fname' => 'required',
            'age' => 'required',
            'address' => 'required',
            'contactno' => 'required',
            'email' => 'required',
        ]);

        $post = new Post;
        $post->fullname = $request->input('fname');
        $post->age = $request->input('age');
        $post->address = $request->input('address');
        $post->contactno = $request->input('contactno');
        $post->email = $request->input('email');
        $post->save();

        return redirect('/ums')->with('success', 'New User Created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $post=Post::find($id);
        return view('ums.show')->with('post', $post);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $post = Post::find($id);
        return view('ums.edit')->with('post', $post);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'fname' => 'required',
            'age' => 'required',
            'address' => 'required',
            'contactno' => 'required',
            'email' => 'required',
        ]);

        $post = Post::find($id);
        $post->fullname = $request->input('fname');
        $post->age = $request->input('age');
        $post->address = $request->input('address');
        $post->contactno = $request->input('contactno');
        $post->email = $request->input('email');
        $post->save();

        return redirect('/ums')->with('success', 'Information was Successfully Updated.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = Post::find($id);
        $post->delete();
        return redirect('/ums')->with('success', 'Record was Successfully Deleted.');
    }
}
